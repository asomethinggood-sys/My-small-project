# Source and licensing

Prepared from https://github.com/asomethinggood-sys/My-small-project/tree/arena%2Ff056ce38-my-small-project . Preserve android/LICENSE, android/THIRD_PARTY.md and bundled dependency notices when redistributing. The destination changes discovery ownership; it does not erase original authorship or license obligations.
